import React from 'react';
import TaskListComponent from '../components/TaskList';

const TaskList = () => {
  return <TaskListComponent />;
};

export default TaskList; 