import React from 'react';

function App() {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>Employee Management System</h1>
      <p>Welcome to the Employee Management System!</p>
    </div>
  );
}

export default App; 