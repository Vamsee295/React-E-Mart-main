import React from 'react';
import TaskFormComponent from '../components/TaskForm';

const TaskForm = () => {
  return <TaskFormComponent />;
};

export default TaskForm; 